# Migração de profile: `cerberus-2026-10-10` → `cerberus-fs-2026-10-24`

> Privado: não publicar. Gerado por `rftool profile migrate` em 2026-10-24 10:54 UTC.

- Binário antigo: `F:\Arquivo\RF Tool\research\cerberus_dump\RF_Online_stage_20261010.exe`
- Binário novo: `F:\Arquivo\RF Tool\research\cerberus_dump\RF_Online_fs_20261024.exe` · SHA-1 `e06a1377ee18cc21be719dad338d448dcd352a7b`

## Resumo

| Campos do profile | Achados | Ambíguos | Não achados |
|---|---|---|---|
| 95 | 93 | 0 | 2 |

Contando também âncoras, verificações de layout e constantes da DLL: 95.3 % dos 402 endereços achados.
Campos ambíguos e não achados **foram removidos** do profile novo (nunca se inventa endereço): a lista de tarefas de RE está abaixo.

## Deslocamento por seção (novo − antigo)

- `.data`: todos os 46 endereços achados deslocaram **+0x0** (deslocamento uniforme de seção).
- `.rdata`: todos os 20 endereços achados deslocaram **+0x0** (deslocamento uniforme de seção).
- `.text`: todos os 242 endereços achados deslocaram **+0x0** (deslocamento uniforme de seção).

## Campos achados

| Campo | Antigo | Novo | Delta | Apoio | Confiança | Observações |
|---|---|---|---|---|---|---|
| `pointers.player` | `RF_Online.bin+0x1F3B5F8` | `RF_Online.bin+0x1F3B5F8` | +0x0 | 13 | alta |  |
| `pointers.target_struct` | `RF_Online.bin+0xB41214` | `RF_Online.bin+0xB41214` | +0x0 | 12 | alta |  |
| `icon_bars.vtable` | `0x00A585E4` | `0x00A585E4` | +0x0 | 3 | alta |  |
| `camera.view` | `RF_Online.bin+0x203F950` | `RF_Online.bin+0x203F950` | +0x0 | 9 | alta |  |
| `camera.projection` | `RF_Online.bin+0x203FA10` | `RF_Online.bin+0x203FA10` | +0x0 | 8 | alta |  |
| `camera.state_ptr` | `RF_Online.bin+0x1F3B604` | `RF_Online.bin+0x1F3B604` | +0x0 | 9 | alta |  |
| `camera.mouse.yaw_deg` | `RF_Online.bin+0x1F38E80` | `RF_Online.bin+0x1F38E80` | +0x0 | 10 | alta |  |
| `camera.mouse.pitch_deg` | `RF_Online.bin+0x1F38E84` | `RF_Online.bin+0x1F38E84` | +0x0 | 10 | alta |  |
| `camera.mouse.yaw_anchor_deg` | `RF_Online.bin+0x1F38E88` | `RF_Online.bin+0x1F38E88` | +0x0 | 8 | alta |  |
| `camera.mouse.pitch_anchor_deg` | `RF_Online.bin+0x1F38E8C` | `RF_Online.bin+0x1F38E8C` | +0x0 | 6 | alta |  |
| `camera.mouse.mouse_y_anchor` | `RF_Online.bin+0x1F38E90` | `RF_Online.bin+0x1F38E90` | +0x0 | 7 | alta |  |
| `camera.mouse.mouse_x_anchor` | `RF_Online.bin+0x1F38E94` | `RF_Online.bin+0x1F38E94` | +0x0 | 10 | alta |  |
| `camera.mouse.wheel_distance` | `RF_Online.bin+0x71611C` | `RF_Online.bin+0x71611C` | +0x0 | 5 | alta |  |
| `camera.input.mouse_x` | `RF_Online.bin+0x203E640` | `RF_Online.bin+0x203E640` | +0x0 | 9 | alta |  |
| `camera.input.mouse_y` | `RF_Online.bin+0x203E644` | `RF_Online.bin+0x203E644` | +0x0 | 10 | alta |  |
| `camera.input.wheel` | `RF_Online.bin+0x203E648` | `RF_Online.bin+0x203E648` | +0x0 | 8 | alta |  |
| `camera.input.buttons` | `RF_Online.bin+0x203E658` | `RF_Online.bin+0x203E658` | +0x0 | 10 | alta |  |
| `camera.input.screen_w` | `RF_Online.bin+0x203F664` | `RF_Online.bin+0x203F664` | +0x0 | 9 | alta |  |
| `camera.input.screen_h` | `RF_Online.bin+0x203F668` | `RF_Online.bin+0x203F668` | +0x0 | 9 | alta |  |
| `camera.input.frame_dt` | `RF_Online.bin+0x203CB88` | `RF_Online.bin+0x203CB88` | +0x0 | 3 | alta |  |
| `camera.eye` | `RF_Online.bin+0x203FA00` | `RF_Online.bin+0x203FA00` | +0x0 | 10 | alta |  |
| `camera.functions.set_pitch` | `0x426760` | `0x426760` | +0x0 | 10 | alta |  |
| `camera.functions.set_yaw` | `0x426780` | `0x426780` | +0x0 | 11 | alta |  |
| `camera.functions.set_distance` | `0x4267A0` | `0x4267A0` | +0x0 | 10 | alta |  |
| `camera.functions.set_angles_changed` | `0x4267E0` | `0x4267E0` | +0x0 | 5 | alta |  |
| `camera.functions.get_pitch` | `0x40AEB0` | `0x40AEB0` | +0x0 | 11 | alta |  |
| `camera.functions.get_yaw` | `0x40ABC0` | `0x40ABC0` | +0x0 | 9 | alta |  |
| `camera.functions.get_distance` | `0x51B200` | `0x51B200` | +0x0 | 8 | alta |  |
| `camera.functions.frame_apply_to_engine` | `0x6F87B0` | `0x6F87B0` | +0x0 | 3 | alta |  |
| `camera.functions.engine_build_view` | `0x7D3500` | `0x7D3500` | +0x0 | 3 | alta |  |
| `camera.functions.engine_build_view_and_eye` | `0x7D3780` | `0x7D3780` | +0x0 | 2 | média |  |
| `camera.functions.mouse_handler` | `0x521A40` | `0x521A40` | +0x0 | 3 | alta |  |
| `camera.functions.camera_rot_keys_handler` | `0x529D70` | `0x529D70` | +0x0 | 3 | alta |  |
| `camera.functions.zoom_keys_handler` | `0x5296E0` | `0x5296E0` | +0x0 | 3 | alta |  |
| `camera.functions.wheel_zoom` | `0x522790` | `0x522790` | +0x0 | 3 | alta |  |
| `camera.functions.key_dispatcher` | `0x5282C0` | `0x5282C0` | +0x0 | 2 | média |  |
| `globals.region_name.address` | `RF_Online.bin+0x1F8CD40` | `RF_Online.bin+0x1F8CD40` | +0x0 | 3 | alta |  |
| `globals.map_index.address` | `RF_Online.bin+0x1F8CD20` | `RF_Online.bin+0x1F8CD20` | +0x0 | 3 | alta |  |
| `entity_lists.monsters` | `RF_Online.bin+0x1F8CFD8` | `RF_Online.bin+0x1F8CFD8` | +0x0 | 3 | alta |  |
| `entity_lists.npcs_near` | `RF_Online.bin+0x1F8CFE8` | `RF_Online.bin+0x1F8CFE8` | +0x0 | 3 | alta |  |
| `entity_lists.towers` | `RF_Online.bin+0x1F8D008` | `RF_Online.bin+0x1F8D008` | +0x0 | 3 | alta |  |
| `entity_lists.special_players` | `RF_Online.bin+0x1F8D088` | `RF_Online.bin+0x1F8D088` | +0x0 | 3 | alta |  |
| `entity_lists.npcs_map` | `RF_Online.bin+0x1F8D0A8` | `RF_Online.bin+0x1F8D0A8` | +0x0 | 3 | alta |  |
| `entity_lists.players_visible` | `RF_Online.bin+0x1F8CFC8` | `RF_Online.bin+0x1F8CFC8` | +0x0 | 3 | alta |  |
| `entity_lists.monsters_wide` | `RF_Online.bin+0x1F8D098` | `RF_Online.bin+0x1F8D098` | +0x0 | 3 | alta |  |
| `vtables.0x00A41E4C` | `0x00A41E4C` | `0x00A41E4C` | +0x0 | 3 | alta |  |
| `vtables.0x00A41FD4` | `0x00A41FD4` | `0x00A41FD4` | +0x0 | 3 | alta |  |
| `vtables.0x00A450BC` | `0x00A450BC` | `0x00A450BC` | +0x0 | 2 | média |  |
| `vtables.0x00A458BC` | `0x00A458BC` | `0x00A458BC` | +0x0 | 3 | alta |  |
| `vtables.0x00A44E44` | `0x00A44E44` | `0x00A44E44` | +0x0 | 2 | média |  |
| `monster_table.pointer_chain.static` | `RF_Online.bin+0x1F3B628` | `RF_Online.bin+0x1F3B628` | +0x0 | 13 | alta |  |
| `combat.datatable_ptr` | `RF_Online.bin+0x1F3B628` | `RF_Online.bin+0x1F3B628` | +0x0 | 13 | alta |  |
| `combat.sf_object.vtable` | `0x00A425EC` | `0x00A425EC` | +0x0 | 2 | média |  |
| `combat.request_pending.address` | `0xB40634` | `0xB40634` | +0x0 | 10 | alta |  |
| `combat.global_delay` | `0xB3EB18` | `0xB3EB18` | +0x0 | 4 | alta |  |
| `combat.network_manager_ptr` | `RF_Online.bin+0x1F3B5EC` | `RF_Online.bin+0x1F3B5EC` | +0x0 | 10 | alta |  |
| `combat.screen_ptr` | `RF_Online.bin+0x1F3B674` | `RF_Online.bin+0x1F3B674` | +0x0 | 10 | alta |  |
| `combat.functions.sf_set` | `0x456370` | `0x456370` | +0x0 | 11 | alta |  |
| `combat.functions.sf_set_level` | `0x456A30` | `0x456A30` | +0x0 | 11 | alta |  |
| `combat.functions.act_on_target` | `0x5234E0` | `0x5234E0` | +0x0 | 4 | alta |  |
| `combat.functions.use_sf_pipeline` | `0x40EF10` | `0x40EF10` | +0x0 | 3 | alta |  |
| `combat.functions.use_sf_send` | `0x40F350` | `0x40F350` | +0x0 | 2 | média |  |
| `combat.functions.skill_request_send` | `0x557CE0` | `0x557CE0` | +0x0 | 1 | baixa |  |
| `combat.functions.attack_skill_request_send` | `0x55BB00` | `0x55BB00` | +0x0 | 4 | alta |  |
| `combat.functions.attack_gen_request_send` | `0x55B960` | `0x55B960` | +0x0 | 2 | média |  |
| `combat.functions.send_msg` | `0x53A240` | `0x53A240` | +0x0 | 11 | alta |  |
| `combat.functions.delay_check` | `0x410B20` | `0x410B20` | +0x0 | 4 | alta |  |
| `combat.functions.range_check` | `0x410300` | `0x410300` | +0x0 | 2 | média |  |
| `combat.functions.cost_check` | `0x40FF70` | `0x40FF70` | +0x0 | 2 | média |  |
| `combat.functions.player_range_vfunc` | `0x410890` | `0x410890` | +0x0 | 1 | baixa |  |
| `combat.functions.server_time_request` | `0x5396A0` | `0x5396A0` | +0x0 | 2 | média |  |
| `combat.functions.server_time_handler` | `0x539700` | `0x539700` | +0x0 | 2 | média |  |
| `combat.functions.zone_packet_dispatcher` | `0x52EDF0` | `0x52EDF0` | +0x0 | 1 | baixa |  |
| `combat.functions.assist_packet_dispatcher` | `0x557450` | `0x557450` | +0x0 | 1 | baixa |  |
| `combat.functions.combat_packet_dispatcher` | `0x55B570` | `0x55B570` | +0x0 | 1 | baixa |  |
| `combat.functions.summon_packet_dispatcher` | `0x54B6F0` | `0x54B6F0` | +0x0 | 1 | baixa |  |
| `combat.functions.set_hp` | `0x4169C0` | `0x4169C0` | +0x0 | 11 | alta |  |
| `combat.functions.effect_time_set` | `0x4121F0` | `0x4121F0` | +0x0 | 4 | alta |  |
| `combat.functions.pending_set` | `0x495160` | `0x495160` | +0x0 | 8 | alta |  |
| `combat.functions.use_sf_entry` | `0x40E630` | `0x40E630` | +0x0 | 11 | alta |  |
| `combat.functions.sf_ctor` | `0x456200` | `0x456200` | +0x0 | 13 | alta |  |
| `combat.functions.sf_enable` | `0x4123A0` | `0x4123A0` | +0x0 | 8 | alta |  |
| `combat.functions.selection_getter` | `0x412780` | `0x412780` | +0x0 | 11 | alta |  |
| `combat.functions.selection_clear` | `0x412400` | `0x412400` | +0x0 | 5 | alta |  |
| `combat.functions.selection_setter_exe` | `0x4123C0` | `0x4123C0` | +0x0 | 2 | média |  |
| `combat.functions.selection_call_site` | `0x40E87A` | `0x40E87A` | +0x0 | 1 | baixa |  |
| `combat.functions.ui_manager` | `0x23DB090` | `0x23DB090` | +0x0 | 10 | alta |  |
| `combat.functions.distance` | `0x7B5700` | `0x7B5700` | +0x0 | 10 | alta |  |
| `chat.window_ptr` | `RF_Online.bin+0x1F3B684` | `RF_Online.bin+0x1F3B684` | +0x0 | 12 | alta |  |
| `chat.input_window_ptr` | `RF_Online.bin+0x1F3B688` | `RF_Online.bin+0x1F3B688` | +0x0 | 9 | alta |  |
| `chat.color_table_ptr` | `RF_Online.bin+0x1F5353C` | `RF_Online.bin+0x1F5353C` | +0x0 | 2 | média |  |
| `chat.system_counter` | `RF_Online.bin+0x1F3CA60` | `RF_Online.bin+0x1F3CA60` | +0x0 | 1 | baixa |  |
| `chat.input.caret_owner` | `RF_Online.bin+0x1F3EC08` | `RF_Online.bin+0x1F3EC08` | +0x0 | 10 | alta |  |

## Tarefas de RE dirigida

1. `pointers.picked_entity` — não achado: nenhuma referência direta no código antigo (provável membro de objeto estático): precisa de âncora (slot) ou de RE. Achar no cliente novo o dado que antes ficava em 0x0238D2D8 (.data). O código antigo não o referencia diretamente: ache o objeto estático que o contém (um slot que o código referencia) e some o deslocamento do membro. Dica: provável membro do objeto apontado por [slot 0x0233B5F0] (âncora level_obj_slot, objeto 0x0238CFB8) em +0x320: acrescente um alvo (anchor + deref + delta) ao signatures-*.json depois de conferir o layout.
2. `chat.input.focus_manager_ptr` — não achado: nenhuma referência direta no código antigo (provável membro de objeto estático): precisa de âncora (slot) ou de RE. Achar no cliente novo o dado que antes ficava em 0x023380E4 (.data). Lugares do código antigo que o usam: 0x0051B4A3, 0x006E4DFA, 0x006E4E17; ache as instruções equivalentes no novo e leia o operando.

## Âncoras e verificações de layout

Se as verificações de layout (`layout.*`) acharam o código no binário novo, as constantes de classe usadas pelas âncoras (+0x20 monstros, +0x2C região…) provavelmente continuam iguais.

- `âncora.player_slot`: achado → 0x0233B5F8 (+0x0)
- `âncora.target_struct_slot`: achado → 0x00F41214 (+0x0)
- `âncora.monster_table_slot`: achado → 0x0233B628 (+0x0)
- `âncora.level_obj_slot`: achado → 0x0233B5F0 (+0x0)
- `âncora.map_obj_slot`: achado → 0x0233B5E4 (+0x0)
- `âncora.chat_window_slot`: achado → 0x0233B684 (+0x0)
- `layout.level_obj_layout`: achado → 0x004F6E30 (+0x0)
- `layout.map_obj_region_layout`: achado → 0x006FA380 (+0x0)
- `layout.map_obj_index_layout`: achado → 0x006FA640 (+0x0)
- `layout.chat_addmessage_prologue`: achado → 0x006B2900 (+0x0)
- `layout.chat_addmessage_layout`: achado → 0x006B2BCC (+0x0)
- `layout.chat_board_base_layout`: achado → 0x005D9970 (+0x0)
- `layout.chat_board_deque_layout`: achado → 0x005D9810 (+0x0)
- `layout.chat_textinfo_text_layout`: achado → 0x005D7610 (+0x0)
- `layout.chat_textinfo_color_layout`: achado → 0x005D7720 (+0x0)

## RfTarget.dll (rftarget.c): endereços e assinaturas

Constantes: 66 de 70 achadas. Tabelas de assinaturas: 209 de 222 achadas. As linhas prontas para colar estão no arquivo `.dll.txt` (a DLL NÃO é editada pela ferramenta).

- `dll.FN_CHAT_NEAR` (0x0057B230): não achado: nenhuma assinatura única no binário antigo (função pequena ou genérica, ou o endereço não está em limite de instrução).
- `dll.FN_CHAT_PARTY` (0x0057B4A0): não achado: nenhuma assinatura única no binário antigo (função pequena ou genérica, ou o endereço não está em limite de instrução).
- `dll.VT_NET_CHAT` (0x00A51888): não achado: nenhuma referência direta no código antigo (provável membro de objeto estático): precisa de âncora (slot) ou de RE.
- `dll.SLOT_GUI_MGR` (0x023380E4): não achado: nenhuma referência direta no código antigo (provável membro de objeto estático): precisa de âncora (slot) ou de RE.
- `HUD_CHECKS[2]` engine text wrapper tail (ZENABLE on; ret): não achado: nenhuma assinatura única no binário antigo (função pequena ou genérica, ou o endereço não está em limite de instrução)
- `HUD_CHECKS[3]` engine text vertex builder FUN_00806890: não achado: nenhuma assinatura única no binário antigo (função pequena ou genérica, ou o endereço não está em limite de instrução)
- `CHAT_CHECKS[1]` chat party packet builder FUN_0057B4A0 (sub 5, length byte at +0, text at +1, ret 4): não achado: nenhuma assinatura única no binário antigo (função pequena ou genérica, ou o endereço não está em limite de instrução)
- `CHAT_CHECKS[2]` chat proximity packet builder FUN_0057B230 (sub 2, length byte at +0, text at +1, ret 4): não achado: nenhuma assinatura única no binário antigo (função pequena ou genérica, ou o endereço não está em limite de instrução)
- `CHAT_CHECKS[7]` PartyChatAction::Execute (check, GetProcessor(1), builder FUN_0057B4A0): não achado: nenhuma assinatura única no binário antigo (função pequena ou genérica, ou o endereço não está em limite de instrução)
- `CHAT_CHECKS[8]` GuildChatAction::Execute (check, GetProcessor(1), builder FUN_0057B540): não achado: nenhuma assinatura única no binário antigo (função pequena ou genérica, ou o endereço não está em limite de instrução)
- `CHAT_CHECKS[9]` NormalChatAction::Execute (check, GetProcessor(1), builder FUN_0057B230): não achado: nenhuma assinatura única no binário antigo (função pequena ou genérica, ou o endereço não está em limite de instrução)
- `ITEM_CHECKS[9]` CEquipBoard vtable +0x74 = FUN_004619E0: não achado: nenhuma referência direta no código antigo (provável membro de objeto estático): precisa de âncora (slot) ou de RE
- `ITEM_CHECKS[10]` CEquipBoard vtable +0x50 (drop) = FUN_004617F0: não achado: nenhuma referência direta no código antigo (provável membro de objeto estático): precisa de âncora (slot) ou de RE
- `ITEM_CHECKS[11]` CInventoryBoard vtable +0x50 (drop) = FUN_004692F0: não achado: nenhuma referência direta no código antigo (provável membro de objeto estático): precisa de âncora (slot) ou de RE
- `ITEM_CHECKS[43]` flag clear test FUN_006FDC50 ([+0x74]): não achado: nenhuma assinatura única no binário antigo (função pequena ou genérica, ou o endereço não está em limite de instrução)
- `ITEM_CHECKS[73]` ActOnTarget's table: type 1 (monster) -> 0x523658: não achado: nenhuma assinatura única no binário antigo (função pequena ou genérica, ou o endereço não está em limite de instrução)
- `CHATWIN_CHECKS[8]` CGUIChatWindow constructor stores vtable 0xA6430C: não achado: nenhuma assinatura única no binário antigo (função pequena ou genérica, ou o endereço não está em limite de instrução)

## Limites

- Offsets de CAMPOS de estruturas (player.*, entity.*, target_struct.*, effects.*, camera.state.* …) foram copiados do profile antigo SEM verificação: não são endereços, e uma assinatura não os enxerga. As verificações de layout (layout.* abaixo) e as tabelas da DLL que citam esses deslocamentos dizem se continuam valendo; confira também com `rftool doctor` e um snapshot.
- Assinaturas são bytes do código antigo com operandos de endereço/relocação em curinga (decodificador x86 mínimo, sem SSE avançado/VEX): código recompilado com outra alocação de registradores não casa.
- Dados sem referência direta só se resolvem por âncora (`profiles/signatures-cerberus.json`) e só se o dump novo for da memória viva (valores do `.data` preenchidos).
- Só a seção principal de código (`.text`) é varrida; endereços em seções do empacotador (`.gpt*`) ficam como não achados.
- A ordem relativa das funções é usada como checagem de coerência: um resultado fora de ordem e com uma só assinatura é rebaixado a ambíguo.
